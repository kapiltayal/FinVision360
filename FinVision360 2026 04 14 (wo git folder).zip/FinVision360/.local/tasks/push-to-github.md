# Push Project to GitHub

## What & Why
Push the current committed codebase to the GitHub remote (`origin`) so the latest changes are reflected in the repository at https://github.com/kapiltayal/FinVision360.

## Done looks like
- All local commits are pushed to the `origin` remote on GitHub
- The remote repository reflects the latest state of the project

## Out of scope
- Branch creation or PR workflows
- Force pushing or rewriting history

## Tasks
1. **Push to origin** — Run `git push origin HEAD` to push the current branch to the remote GitHub repository.
